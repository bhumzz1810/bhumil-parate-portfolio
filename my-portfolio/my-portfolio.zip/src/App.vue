<template>
  <div class="bg-green-600 text-white text-5xl p-20">
    Tailwind is alive 🚀
  </div>
</template>

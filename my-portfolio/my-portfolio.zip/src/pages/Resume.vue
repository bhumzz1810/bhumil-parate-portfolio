<template>
  <section class="min-h-screen px-6 py-16">
    <div class="max-w-4xl mx-auto space-y-16">

      <!-- Summary -->
      <div>
        <h1 class="text-4xl font-bold mb-6">Resume</h1>
        <p class="text-gray-400 text-sm mb-3">

          Full-stack developer with hands-on experience building
          production-ready web applications using Laravel and Vue.
          Strong focus on clean architecture, scalable APIs,
          and maintainable frontend systems.
        </p>
      </div>

      <!-- Skills -->
      <div>
        <h2 class="text-2xl font-semibold text-white mb-4">
Skills</h2>

        <div class="grid sm:grid-cols-2 gap-6 text-gray-300">
          <div>
            <h3 class="font-medium text-white mb-2">Backend</h3>
            <ul class="list-disc list-inside space-y-1">
              <li>Laravel 10–12</li>
              <li>REST APIs</li>
              <li>Authentication & Authorization</li>
              <li>MySQL / SQL</li>
              <li>Service-layer architecture</li>
            </ul>
          </div>

          <div>
            <h3 class="font-medium text-white mb-2">Frontend</h3>
            <ul class="list-disc list-inside space-y-1">
              <li>Vue 3 (Composition API)</li>
              <li>TypeScript</li>
              <li>Vue Router</li>
              <li>Tailwind CSS</li>
              <li>Responsive UI design</li>
            </ul>
          </div>

          <div>
            <h3 class="font-medium text-white mb-2">Tools & Practices</h3>
            <ul class="list-disc list-inside space-y-1">
              <li>Git & GitHub</li>
              <li>RESTful design</li>
              <li>Clean code principles</li>
              <li>Basic testing (Pest / PHPUnit)</li>
              <li>Deployment basics</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Experience -->
      <div>
        <h2 class="text-2xl font-semibold text-white mb-4">
Experience & Projects</h2>

        <div class="space-y-10">
          <!-- Project 1 -->
          <div>
            <h3 class="text-xl font-semibold">
              Full-Stack Developer — Rajwadi Tiffin Management System
            </h3>
           <p class="text-gray-400 text-sm mb-3">

              Laravel • Vue • MySQL • Stripe
            </p>
            <ul class="list-disc list-inside text-gray-300 space-y-1">
              <li>Designed and implemented a subscription-based ordering system for a real business</li>
              <li>Built REST APIs with role-based authentication and authorization</li>
              <li>Implemented admin dashboards for managing plans, users, and orders</li>
              <li>Focused on clean architecture and separation of concerns</li>
            </ul>
          </div>

          <!-- Project 2 -->
          <div>
            <h3 class="text-xl font-semibold">
              Full-Stack Developer — Service Subscription Platform
            </h3>
            <p class="text-gray-400 text-sm mb-3">

              Laravel • Vue • Sanctum
            </p>
            <ul class="list-disc list-inside text-gray-300 space-y-1">
              <li>Developed API-first backend using Laravel</li>
              <li>Implemented authentication and protected routes</li>
              <li>Designed scalable database structure for subscriptions</li>
              <li>Integrated frontend with Vue and modern tooling</li>
            </ul>
          </div>
        </div>
      </div>

    </div>
  </section>
</template>

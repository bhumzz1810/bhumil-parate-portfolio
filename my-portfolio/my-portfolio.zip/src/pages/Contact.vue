<template>
  <section class="min-h-screen px-6 py-16 flex items-center">
    <div class="max-w-4xl mx-auto w-full">
      <h1 class="text-4xl font-bold mb-6">Contact</h1>

      <p class="text-gray-300 max-w-2xl mb-10">
        I’m open to full-time, internship, and junior developer opportunities.
        Feel free to reach out if you’d like to discuss a role, a project,
        or just connect.
      </p>

      <div class="space-y-6">
        <!-- Email -->
        <div>
          <p class="text-gray-400 text-sm mb-1">Email</p>
          <a
            href="mailto:your.email@example.com"
            class="text-lg text-indigo-400 hover:underline"
          >
            your.email@example.com
          </a>
        </div>

        <!-- LinkedIn -->
        <div>
          <p class="text-gray-400 text-sm mb-1">LinkedIn</p>
          <a
            href="https://linkedin.com/in/your-linkedin"
            target="_blank"
            class="text-lg text-indigo-400 hover:underline"
          >
            linkedin.com/in/your-linkedin
          </a>
        </div>

        <!-- GitHub -->
        <div>
          <p class="text-gray-400 text-sm mb-1">GitHub</p>
          <a
            href="https://github.com/your-username"
            target="_blank"
            class="text-lg text-indigo-400 hover:underline"
          >
            github.com/your-username
          </a>
        </div>
      </div>
    </div>
  </section>
</template>

<template>
  <footer class="border-t border-gray-800 mt-16">
    <div class="max-w-6xl mx-auto px-6 py-6 text-sm text-gray-400 flex justify-between">
      <span>© 2026 Bhumil Parate</span>
      <span>Built with Vue 3 & Tailwind CSS</span>
    </div>
  </footer>
</template>

<script setup lang="ts">
import { RouterLink } from 'vue-router'
</script>

<template>
  <header class="sticky top-0 bg-gray-950/80 backdrop-blur border-b border-gray-800 z-50">

    <nav class="max-w-6xl mx-auto px-6 py-4 flex flex-col sm:flex-row gap-4 sm:gap-0 justify-between items-center">

      <!-- Logo / Name -->
      <RouterLink
        to="/"
        class="text-lg font-semibold tracking-wide"
      >
        Bhumil Parate
      </RouterLink>

      <!-- Links -->
      <div class="flex gap-6 text-gray-300">
        <RouterLink
  to="/"
  class="hover:text-white"
  :class="{ 'text-white': $route.path === '/' }"
>
  Home
</RouterLink>

<RouterLink
  to="/projects"
  class="hover:text-white"
  :class="{ 'text-white': $route.path === '/projects' }"
>
  Projects
</RouterLink>

<RouterLink
  to="/resume"
  class="hover:text-white"
  :class="{ 'text-white': $route.path === '/resume' }"
>
  Resume
</RouterLink>

<RouterLink
  to="/contact"
  class="hover:text-white"
  :class="{ 'text-white': $route.path === '/contact' }"
>
  Contact
</RouterLink>

      </div>
    </nav>
  </header>
</template>
